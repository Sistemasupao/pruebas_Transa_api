package upao.Transa.domain.Enum;

public enum TipoSuscripcion {
    Basico,
    Estandar,
    PREMIUM,
    Unica,

}
