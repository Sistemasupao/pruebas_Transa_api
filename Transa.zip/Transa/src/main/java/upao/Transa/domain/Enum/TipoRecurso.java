package upao.Transa.domain.Enum;
public enum TipoRecurso {
    DIGITAL,
    FISICO,
    MIXTO
}
