package upao.Transa.domain.Enum;


public enum Role {
    USER,
    AUTHOR,

}
