package upao.Transa.domain.Enum;

public enum Estado {
    INICIADO,
    ENPROCESO,
    FINALIZADO,
    DETENIDO,
}
