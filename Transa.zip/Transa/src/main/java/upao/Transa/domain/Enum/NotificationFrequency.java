package upao.Transa.domain.Enum;

public enum NotificationFrequency {
    DAILY,
    WEEKLY,
    MONTHLY
}
