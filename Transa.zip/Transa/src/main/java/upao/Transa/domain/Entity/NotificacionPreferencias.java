package upao.Transa.domain.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "NotificacionesPreferencias")
public class NotificacionPreferencias {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private Usuario usuario;

    private boolean notifyOnRegistration;
    private boolean notifyOnProfileDeletion;
    private boolean notifyOnGoals;
    private boolean notifyOnPurchases;
}