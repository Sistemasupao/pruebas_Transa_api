package upao.Transa.Mapper;

import org.mapstruct.Mapper;
import upao.Transa.domain.Entity.Autor;
import upao.Transa.dto.request.AutorRequestDTO;
import upao.Transa.dto.response.AutorProfileResponseDTO;

@Mapper(componentModel = "spring")
public interface AutorMapper {

    Autor toAutor(AutorRequestDTO autorRequestDTO);

    AutorProfileResponseDTO toAutorProfileResponseDTO(Autor autor);

}
