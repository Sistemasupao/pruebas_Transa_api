package upao.Transa.Mapper;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;
import upao.Transa.domain.Entity.Recurso;
import upao.Transa.dto.request.RecursoRequestDTO;
import upao.Transa.dto.response.RecursoResponseDTO;

import java.util.List;

@Component
@RequiredArgsConstructor
public class RecursoMapper {
    private final ModelMapper modelMapper;

    public Recurso toEntity(RecursoRequestDTO recursoRequesDTO) {
        return modelMapper.map(recursoRequesDTO, Recurso.class);
    }

    public RecursoResponseDTO toResponseDto(Recurso recurso) {
        return modelMapper.map(recurso, RecursoResponseDTO.class);
    }

    public List<RecursoResponseDTO> toResponseDtoList(List<Recurso> recurso) {
        return recurso.stream()
                .map(this::toResponseDto)
                .toList();
    }
}
