package upao.Transa.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import upao.Transa.Service.SuscripcionService;
import upao.Transa.domain.Entity.Suscripcion;

@RestController
@RequestMapping("/api/suscripcion")
public class SuscripcionController {

    @Autowired
    private SuscripcionService suscripcionService;

    @PostMapping("/{usuarioId}/contenido/{contenidoId}")
    public ResponseEntity<Suscripcion> suscribirUsuario(@PathVariable Long usuarioId, @PathVariable Long contenidoId) {
        Suscripcion nuevaSuscripcion = suscripcionService.suscribirUsuarioAContenido(usuarioId, contenidoId);
        return ResponseEntity.ok(nuevaSuscripcion);
    }
}