package upao.Transa.Controller;

import upao.Transa.Service.modelsDTO.NotificationPreferencesDTO;
import upao.Transa.Service.EmailService;
import upao.Transa.Service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/usuarios")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final EmailService emailService;

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        try {
            String userEmail = userService.findEmailById(id);
            userService.delete(id);
            emailService.sendAccountDeletionEmail(userEmail);
            return ResponseEntity.ok("Usuario eliminado exitosamente");
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @DeleteMapping("/eliminar/{correo}")
    public ResponseEntity<String> eliminarUsuarioPorCorreo(@PathVariable String correo) {
        try {
            userService.eliminarUsuarioPorCorreo(correo);
            emailService.sendAccountDeletionEmail(correo);
            return ResponseEntity.ok("El usuario con el correo " + correo + " ha sido eliminado exitosamente");
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @PostMapping("/preferences")
    public ResponseEntity<String> updateNotificationPreferences(@RequestBody NotificationPreferencesDTO preferences) {
        userService.updateNotificationPreferences(preferences);
        return ResponseEntity.ok("Preferencias actualizadas con éxito.");
    }
    @PostMapping("/{id}/registrarPesoAltura")
    public ResponseEntity<String> registrarPesoAltura(
            @PathVariable Long id,
            @RequestParam Double peso,
            @RequestParam Double altura) {

        try {
            userService.registrarPesoAltura(id, peso, altura);
            return ResponseEntity.ok("Peso y altura registrados con éxito.");
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @PutMapping("/{id}/actualizarPesoAltura")
    public ResponseEntity<String> actualizarPesoAltura(@PathVariable Long id, @RequestBody Map<String, Double> payload) {
        try {
            Double nuevoPeso = payload.get("peso");
            Double nuevaAltura = payload.get("altura");
            userService.actualizarPesoAltura(id, nuevoPeso, nuevaAltura);
            return ResponseEntity.ok("Peso y altura actualizados con éxito.");
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @GetMapping("/{id}/imc")
    public ResponseEntity<String> obtenerIMC(@PathVariable Long id) {
        try {
            Double imc = userService.calcularIMC(id);
            if (imc != null) {
                return ResponseEntity.ok("Tu IMC es: " + imc);
            } else {
                return ResponseEntity.status(400).body("Peso o altura no están registrados correctamente.");
            }
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

}
