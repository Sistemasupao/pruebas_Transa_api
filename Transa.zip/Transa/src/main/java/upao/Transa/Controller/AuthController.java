package upao.Transa.Controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import upao.Transa.Service.EmailService;
import upao.Transa.Security.TokenProvider;
import upao.Transa.Service.UserService;
import upao.Transa.Service.AutorService;
import upao.Transa.domain.Entity.Usuario;
import upao.Transa.domain.Entity.Autor;
import upao.Transa.dto.request.AuthRequesDTO;
import upao.Transa.dto.request.SignupRequesDTO;
import upao.Transa.dto.request.AutorRequestDTO;
import upao.Transa.dto.response.AuthResponseDTO;
import upao.Transa.dto.response.UserProfileResponseDTO;
import upao.Transa.dto.response.AutorProfileResponseDTO;

import java.util.Map;

@RequiredArgsConstructor
@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UserService userService;
    private final AutorService autorService;
    private final TokenProvider tokenProvider;
    private final EmailService emailService;

    /**
     * Endpoint para iniciar sesión.
     */
    @PostMapping("/sign-in")
    public ResponseEntity<AuthResponseDTO> login(@RequestBody AuthRequesDTO authRequesDTO) {
        AuthResponseDTO response = userService.signIn(authRequesDTO);
        return ResponseEntity.ok(response);
    }

    /**
     * Registro de usuario normal.
     */
    @PostMapping("/sign-up")
    public ResponseEntity<UserProfileResponseDTO> signup(@RequestBody SignupRequesDTO signupRequesDTO) {
        UserProfileResponseDTO response = userService.signup(signupRequesDTO);
        return ResponseEntity.ok(response);
    }

    /**
     * Registro de un autor.
     */
    @PreAuthorize("hasRole('ROLE_AUTHOR')")
    @PostMapping("/register")
    public ResponseEntity<AutorProfileResponseDTO> registerAutor(@Validated @RequestBody AutorRequestDTO autorRequestDTO) {

        if (autorRequestDTO.getContrasena() == null || autorRequestDTO.getContrasena().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }


        AutorProfileResponseDTO response;
        try {
            response = autorService.registerAutor(autorRequestDTO);
        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        return ResponseEntity.ok(response);
    }


    @PostMapping("/send-email-link")
    public ResponseEntity<?> sendEmailLink(@RequestBody Map<String, String> request) {
        String email = request.get("email");

        String token = tokenProvider.createEmailVerificationToken(new Usuario(email));

        String verificationLink = "http://localhost:4200/verify-email?token=" + token;

        emailService.sendVerificationEmail(email, verificationLink);

        return ResponseEntity.ok("Enlace de acceso enviado al correo.");
    }

    @PostMapping("/verify-email")
    public ResponseEntity<AuthResponseDTO> verifyEmail(@RequestBody Map<String, String> request) {
        String token = request.get("token");

        if (tokenProvider.validateToken(token)) {
            String email = tokenProvider.getEmailFromToken(token);

            String jwtToken = tokenProvider.createAccessToken(new UsernamePasswordAuthenticationToken(email, null));

            UserProfileResponseDTO userProfile = userService.findByCorreo(email);

            return ResponseEntity.ok(new AuthResponseDTO(jwtToken, userProfile));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");


        if (email == null || email.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("El correo no puede estar vacío.");
        }


        String token = tokenProvider.createPasswordResetToken(email);
        String resetLink = "http://tu-frontend.com/reset-password?token=" + token;

        emailService.sendPasswordResetEmail(email, resetLink);

        return ResponseEntity.ok("Enlace de recuperación enviado al correo.");
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) {
        String token = request.get("token");
        String newPassword = request.get("newPassword");

        if (tokenProvider.validateToken(token)) {
            String email = tokenProvider.getEmailFromToken(token);
            userService.resetPassword(email, newPassword);
            return ResponseEntity.ok("Contraseña restablecida con éxito.");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Token inválido.");
        }
    }

}
