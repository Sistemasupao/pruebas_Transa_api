package upao.Transa.Controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import upao.Transa.Service.RecursoService;
import upao.Transa.dto.request.RecursoRequestDTO;
import upao.Transa.dto.response.RecursoResponseDTO;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/recursos")
public class RecursoController {

    private final RecursoService recursoService;


    @PreAuthorize("hasRole('AUTOR')")
    @PostMapping("/registrar")
    public ResponseEntity<RecursoResponseDTO> registrarRecurso(@AuthenticationPrincipal UserDetails userDetails,
                                                               @RequestBody RecursoRequestDTO recursoRequestDTO) {
        RecursoResponseDTO response = recursoService.registrarRecurso(recursoRequestDTO, userDetails.getUsername());
        return ResponseEntity.ok(response);
    }


    @PreAuthorize("hasRole('AUTOR')")
    @PutMapping("/actualizar/{id}")
    public ResponseEntity<RecursoResponseDTO> actualizarRecurso(@AuthenticationPrincipal UserDetails userDetails,
                                                                @PathVariable Long id,
                                                                @RequestBody RecursoRequestDTO recursoRequestDTO) {
        RecursoResponseDTO response = recursoService.actualizarRecurso(id, recursoRequestDTO, userDetails.getUsername());
        return ResponseEntity.ok(response);
    }


    @PreAuthorize("hasRole('AUTOR')")
    @GetMapping("/mis-recursos")
    public ResponseEntity<List<RecursoResponseDTO>> obtenerRecursosPorAutor(@AuthenticationPrincipal UserDetails userDetails) {
        List<RecursoResponseDTO> recursos = recursoService.obtenerRecursosPorAutor(userDetails.getUsername());
        return ResponseEntity.ok(recursos);
    }
}
