package upao.Transa.Controller;

import jakarta.mail.MessagingException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import upao.Transa.Service.NotificationService;
import upao.Transa.Service.NotificationPreferenceService;
import upao.Transa.domain.Entity.NotificacionPreferencias;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    private final NotificationService notificationService;
    private final NotificationPreferenceService preferenceService;

    public NotificationController(NotificationService notificationService, NotificationPreferenceService preferenceService) {
        this.notificationService = notificationService;
        this.preferenceService = preferenceService;
    }

    @PostMapping("/send-registration")
    public ResponseEntity<String> sendRegistrationNotification(@RequestParam Long userId) {
        try {
            NotificacionPreferencias preferences = preferenceService.getUserPreferences(userId);
            if (preferences.isNotifyOnRegistration()) {
                notificationService.sendRegistrationNotification(preferences.getUsuario().getCorreo());
            }
            return ResponseEntity.ok("Registration notification processed");
        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error sending notification");
        }
    }

    @PostMapping("/send-profile-deletion")
    public ResponseEntity<String> sendProfileDeletionNotification(@RequestParam Long userId) {
        try {
            NotificacionPreferencias preferences = preferenceService.getUserPreferences(userId);
            if (preferences.isNotifyOnProfileDeletion()) {
                notificationService.sendProfileDeletionNotification(preferences.getUsuario().getCorreo());
            }
            return ResponseEntity.ok("Profile deletion notification processed");
        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error sending notification");
        }
    }

    @PostMapping("/send-goal-notification")
    public ResponseEntity<String> sendGoalNotification(@RequestParam Long userId, @RequestParam boolean goalMet) {
        try {
            NotificacionPreferencias preferences = preferenceService.getUserPreferences(userId);
            if (preferences.isNotifyOnGoals()) {
                notificationService.sendGoalNotification(preferences.getUsuario().getCorreo(), goalMet);
            }
            return ResponseEntity.ok("Goal notification processed");
        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error sending notification");
        }
    }

    @PostMapping("/send-purchase-notification")
    public ResponseEntity<String> sendPurchaseNotification(@RequestParam Long userId) {
        try {
            NotificacionPreferencias preferences = preferenceService.getUserPreferences(userId);
            if (preferences.isNotifyOnPurchases()) {
                notificationService.sendPurchaseNotification(preferences.getUsuario().getCorreo());
            }
            return ResponseEntity.ok("Purchase notification processed");
        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error sending notification");
        }
    }
}
