/**
package upao.Transa.Controller;

import lombok.AllArgsConstructor;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import upao.Transa.Service.CheckoutService;
import upao.Transa.dto.response.PaypalCaptureResponse;
import upao.Transa.dto.response.PaypalOrderResponse;

@AllArgsConstructor
@RestController
@RequestMapping("/checkout")
public class CheckoutController {
    private CheckoutService checkoutService;
    @PostMapping("/paypal/create")
    public PaypalOrderResponse createPaypalOrder(
            @RequestParam Long recursoid,
            @RequestParam String returnUrl,
            @RequestParam String cancelUrl

    ){
        return checkoutService.createPaypalPaymentUrl(recursoid,returnUrl,cancelUrl);
    }
    @PostMapping("/paypal/capture")
    public PaypalCaptureResponse capturePaypalOrder(@RequestParam String orderId){
        return checkoutService.capturPaypalPayment(orderId);
    }
}
 **/
