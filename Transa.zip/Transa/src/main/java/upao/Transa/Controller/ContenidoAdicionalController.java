/*package upao.Transa.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import upao.Transa.Repository.ContenidoAdicionalRepository;
import upao.Transa.domain.Entity.ContenidoAdicional;

import java.util.List;

@RestController
@RequestMapping("/api/contenido-adicional")
public class ContenidoAdicionalController {

    @Autowired
    private ContenidoAdicionalRepository contenidoAdicionalRepository;

    @GetMapping
    public List<ContenidoAdicional> listarContenidos() {
        return contenidoAdicionalRepository.findAll();
    }
    @PostMapping
    public ResponseEntity<ContenidoAdicional> createContenidoAdicional(@RequestBody ContenidoAdicional contenidoAdicional) {
        ContenidoAdicional nuevoContenido = contenidoAdicionalService.save(contenidoAdicional);
        return ResponseEntity.ok(nuevoContenido);
    }
}
*/