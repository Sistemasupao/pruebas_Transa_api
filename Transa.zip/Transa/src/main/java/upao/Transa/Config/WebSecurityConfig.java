package upao.Transa.Config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import upao.Transa.Security.JWTConfigurer;
import upao.Transa.Security.TokenProvider;

@RequiredArgsConstructor
@Configuration
public class WebSecurityConfig {

    private final TokenProvider tokenProvider;

    @Bean
    public SecurityFilterChain jwtSecurityFilterChain(HttpSecurity http) throws Exception {
        http.cors(Customizer.withDefaults())
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests((authz) -> authz
                        .requestMatchers("/auth/sign-up", "/recursos/registrar", "/api/v1/auth/register", // Cambia esto
                                "/usuarios/{id}/imc", "/usuarios/{id}/actualizarPesoAltura",
                                "/usuarios/{id}/registrarPesoAltura", "/auth/sign-in",
                                "/contenidos-adicionales", "/auth/send-email-link",
                                "/auth/verify-email", "/auth/forgot-password",
                                "/auth/reset-password", "/usuarios/eliminar/{correo}",
                                "/usuarios/{id}", "/user/send-email",
                                "/notifications/send-registration", "/notifications/send-profile-deletion",
                                "/notifications/send-goal-notification", "/notifications/send-purchase-notification")
                        .permitAll()
                        .anyRequest().authenticated()
                )
                .sessionManagement(h -> h.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .with(new JWTConfigurer(tokenProvider), Customizer.withDefaults());
        return http.build();
    }
}