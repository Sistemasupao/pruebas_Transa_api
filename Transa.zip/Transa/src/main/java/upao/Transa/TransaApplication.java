package upao.Transa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransaApplication.class, args);
	}

}
