package upao.Transa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import upao.Transa.domain.Entity.Foro;

public interface ForoRepository extends JpaRepository<Foro, Long> {
}
