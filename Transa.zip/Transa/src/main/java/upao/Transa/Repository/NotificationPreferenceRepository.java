package upao.Transa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import upao.Transa.domain.Entity.NotificacionPreferencias;

@Repository
public interface NotificationPreferenceRepository extends JpaRepository<NotificacionPreferencias, Long> {
    NotificacionPreferencias findByUsuario_Id(Long userId);
}
