package upao.Transa.Service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import upao.Transa.Exception.BadRequestException;
import upao.Transa.Mapper.UserMapper;
import upao.Transa.Repository.UserRepository;
import upao.Transa.Security.TokenProvider;
import upao.Transa.Service.modelsDTO.NotificationPreferencesDTO;
import upao.Transa.domain.Entity.Usuario;
import upao.Transa.dto.request.AuthRequesDTO;
import upao.Transa.dto.request.SignupRequesDTO;
import upao.Transa.dto.response.AuthResponseDTO;
import upao.Transa.dto.response.UserProfileResponseDTO;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;
    private final TokenProvider tokenProvider;
    private final AuthenticationManager authenticationManager; // Asegúrate de incluir esto
    private final EmailService emailService;

    /**
     * Autenticación de un usuario.
     */
    @Transactional(readOnly = true)
    public AuthResponseDTO signIn(AuthRequesDTO authRequestDTO) {
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                authRequestDTO.getCorreo(),
                authRequestDTO.getContrasena()
        );

        Authentication authentication = authenticationManager.authenticate(authenticationToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        String accessToken = tokenProvider.createAccessToken(authentication);
        UserProfileResponseDTO userProfileDTO = findByCorreo(authRequestDTO.getCorreo());
        return userMapper.toAuthResponseDTO(accessToken, userProfileDTO);
    }

    @Transactional
    public UserProfileResponseDTO signup(SignupRequesDTO signupRequestDTO) {
        boolean emailAlreadyExists = userRepository.existsByCorreo(signupRequestDTO.getCorreo());
        if (emailAlreadyExists) {
            throw new BadRequestException("El correo electrónico ya está siendo usado por otro usuario.");
        }

        Usuario usuario = userMapper.toUser(signupRequestDTO);
        usuario.setContrasena(passwordEncoder.encode(signupRequestDTO.getContrasena()));
        usuario.setRole(signupRequestDTO.getRole());
        userRepository.save(usuario);

        emailService.sendEmail(
                usuario.getCorreo(),
                "Bienvenido a la plataforma",
                "Hola " + usuario.getNombre() + ", gracias por registrarte en nuestra plataforma."
        );

        return userMapper.toUserProfileResponseDTO(usuario);
    }

    public UserProfileResponseDTO findByCorreo(String correo) {
        Usuario usuario = userRepository.findOneByCorreo(correo)
                .orElseThrow(() -> new BadRequestException("Usuario no encontrado."));
        return userMapper.toUserProfileResponseDTO(usuario);
    }

    @Transactional
    public void resetPassword(String email, String newPassword) {
        Usuario usuario = userRepository.findOneByCorreo(email)
                .orElseThrow(() -> new BadRequestException("Usuario no encontrado."));

        usuario.setContrasena(passwordEncoder.encode(newPassword));
        userRepository.save(usuario);
    }

    @Transactional
    public void eliminarPerfil() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new BadRequestException("No hay usuario autenticado.");
        }

        String correoUsuario = authentication.getName();
        Usuario usuario = userRepository.findOneByCorreo(correoUsuario)
                .orElseThrow(() -> new BadRequestException("Usuario no encontrado."));
        userRepository.delete(usuario);
    }

    @Transactional
    public void eliminarUsuarioPorCorreo(String correo) {
        Usuario usuario = userRepository.findOneByCorreo(correo)
                .orElseThrow(() -> new BadRequestException("Usuario no encontrado."));
        userRepository.delete(usuario);
    }

    @Transactional
    public void delete(Long id) {
        Usuario usuario = userRepository.findById(id)
                .orElseThrow(() -> new BadRequestException("Usuario no encontrado con el ID: " + id));
        userRepository.delete(usuario);
    }

    public String findEmailById(Long id) {
        Usuario user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario con ID " + id + " no encontrado"));
        return user.getCorreo();
    }

    public void updateNotificationPreferences(NotificationPreferencesDTO preferences) {
        Optional<Usuario> optionalUsuario = userRepository.findOneByCorreo(preferences.getEmail());

        if (optionalUsuario.isPresent()) {
            Usuario usuario = optionalUsuario.get();
            usuario.setNotificationFrequency(preferences.getFrequency());
            userRepository.save(usuario);
        } else {
            throw new RuntimeException("Usuario no encontrado");
        }
    }

    public void registrarPesoAltura(Long id, Double peso, Double altura) {
        Usuario usuario = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        usuario.setPeso(peso);
        usuario.setAltura(altura);
        userRepository.save(usuario);
    }

    public Double actualizarPesoAlturaYCalcularIMC(Long id, Double peso, Double altura) {
        Usuario usuario = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        usuario.setPeso(peso);
        usuario.setAltura(altura);
        userRepository.save(usuario);
        return usuario.calcularIMC();
    }

    public Double calcularIMC(Long id) {
        Usuario usuario = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        return usuario.calcularIMC();
    }

    public void actualizarPesoAltura(Long id, Double nuevoPeso, Double nuevaAltura) {
        Usuario usuario = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        usuario.setPeso(nuevoPeso);
        usuario.setAltura(nuevaAltura);
        userRepository.save(usuario);
    }
}
