package upao.Transa.Service;

import jakarta.mail.MessagingException;

public interface INotificationService {
    void sendRegistrationNotification(String recipientEmail) throws MessagingException;
    void sendProfileDeletionNotification(String recipientEmail) throws MessagingException;
    void sendGoalNotification(String recipientEmail, boolean goalMet) throws MessagingException;
    void sendPurchaseNotification(String recipientEmail) throws MessagingException;
}
