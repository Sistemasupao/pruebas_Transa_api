package upao.Transa.Service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder; // Importar PasswordEncoder
import org.springframework.stereotype.Service;
import upao.Transa.Exception.BadRequestException;
import upao.Transa.Mapper.AutorMapper;
import upao.Transa.Repository.AutorRepository;
import upao.Transa.domain.Entity.Autor;
import upao.Transa.domain.Enum.Role;
import upao.Transa.dto.request.AutorRequestDTO;
import upao.Transa.dto.response.AutorProfileResponseDTO;

@Service
@RequiredArgsConstructor
public class AutorService {

    private final AutorRepository autorRepository;
    private final AutorMapper autorMapper;
    private final PasswordEncoder passwordEncoder;

    /**
     * Registro de un nuevo autor.
     */
    public AutorProfileResponseDTO registerAutor(AutorRequestDTO autorRequestDTO) {

        Autor autor = new Autor();
        autor.setNombre(autorRequestDTO.getNombre());
        autor.setCorreo(autorRequestDTO.getCorreo());
        autor.setEspecialidad(autorRequestDTO.getEspecialidad());
        autor.setTelefono(autorRequestDTO.getTelefono());
        autor.setRole(Role.valueOf(autorRequestDTO.getRole()));


        String contrasenaCifrada = passwordEncoder.encode(autorRequestDTO.getContrasena());
        autor.setContrasena(contrasenaCifrada);


        Autor nuevoAutor = autorRepository.save(autor);

        AutorProfileResponseDTO response = new AutorProfileResponseDTO();
        response.setId(nuevoAutor.getId());
        response.setNombre(nuevoAutor.getNombre());
        response.setCorreo(nuevoAutor.getCorreo());
        response.setEspecialidad(nuevoAutor.getEspecialidad());
        response.setTelefono(nuevoAutor.getTelefono());
        response.setRole(nuevoAutor.getRole().name());

        return response;
    }

    /**
     * Encontrar autor por correo.
     */
    public Autor findByCorreo(String correo) {
        return autorRepository.findOneByCorreo(correo)
                .orElseThrow(() -> new BadRequestException("Autor no encontrado."));
    }
}
