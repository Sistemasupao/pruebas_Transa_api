package upao.Transa.Service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import upao.Transa.domain.Entity.Autor;
import upao.Transa.domain.Entity.Recurso;
import upao.Transa.Repository.AutorRepository; // Asegúrate de tener este repositorio
import upao.Transa.Repository.RecursoRepository;
import upao.Transa.dto.request.RecursoRequestDTO;
import upao.Transa.dto.response.RecursoResponseDTO;
import upao.Transa.Exception.ResourceNotFoundException;
import upao.Transa.Exception.UnauthorizedException;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RecursoService {

    private final RecursoRepository recursoRepository;
    private final AutorRepository autorRepository;

    public RecursoResponseDTO registrarRecurso(RecursoRequestDTO recursoRequestDTO, String nombre) {
        Autor autor = autorRepository.findByNombre(recursoRequestDTO.getAutorNombre())
                .orElseThrow(() -> new ResourceNotFoundException("Autor no encontrado"));

        Recurso nuevoRecurso = new Recurso();
        nuevoRecurso.setNombreRecurso(recursoRequestDTO.getNombreRecurso());
        nuevoRecurso.setDescripcionRecurso(recursoRequestDTO.getDescripcionRecurso());
        nuevoRecurso.setPrecioRecurso(recursoRequestDTO.getPrecioRecurso());
        nuevoRecurso.setTipoRecurso(recursoRequestDTO.getTipoRecurso());
        nuevoRecurso.setAutor(autor);

        recursoRepository.save(nuevoRecurso);
        return new RecursoResponseDTO(nuevoRecurso);
    }

    public RecursoResponseDTO actualizarRecurso(Long id, RecursoRequestDTO recursoRequestDTO, String nombre) {
        Recurso recurso = recursoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Recurso no encontrado"));

        if (!recurso.getAutor().getNombre().equals(nombre)) {
            throw new UnauthorizedException("No tienes permiso para actualizar este recurso");
        }

        Autor autor = autorRepository.findByNombre(recursoRequestDTO.getAutorNombre())
                .orElseThrow(() -> new ResourceNotFoundException("Autor no encontrado"));

        recurso.setNombreRecurso(recursoRequestDTO.getNombreRecurso());
        recurso.setDescripcionRecurso(recursoRequestDTO.getDescripcionRecurso());
        recurso.setPrecioRecurso(recursoRequestDTO.getPrecioRecurso());
        recurso.setTipoRecurso(recursoRequestDTO.getTipoRecurso());
        recurso.setAutor(autor);

        recursoRepository.save(recurso);

        return new RecursoResponseDTO(recurso);
    }

    public List<RecursoResponseDTO> obtenerRecursosPorAutor(String nombre) {
        List<Recurso> recursos = recursoRepository.findByAutorNombre(nombre);
        return recursos.stream().map(RecursoResponseDTO::new).toList();
    }
}
