package upao.Transa.Service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import jakarta.mail.MessagingException;
import upao.Transa.Repository.UserRepository;
import upao.Transa.Service.modelsDTO.EmailDTO;
import upao.Transa.domain.Entity.Suscripcion;
import upao.Transa.domain.Entity.Usuario;
import upao.Transa.domain.Enum.NotificationFrequency;

import java.util.List;

@Service
public class NotificationService {

    private final IEmailService emailService;
    private final UserRepository userRepository;

    public NotificationService(IEmailService emailService, UserRepository userRepository) {
        this.emailService = emailService;
        this.userRepository = userRepository;
    }

    public void sendRegistrationNotification(String recipientEmail) throws MessagingException {
        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setDestinatario(recipientEmail);
        emailDTO.setAsunto("Welcome to our system!");
        emailDTO.setMensaje("Thank you for registering. We are happy to have you.");

        emailService.sendMail(emailDTO);
    }

    public void sendProfileDeletionNotification(String recipientEmail) throws MessagingException {
        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setDestinatario(recipientEmail);
        emailDTO.setAsunto("Your profile has been deleted");
        emailDTO.setMensaje("We are sorry to see you go. Your profile has been successfully deleted.");

        emailService.sendMail(emailDTO);
    }

    public void sendGoalNotification(String recipientEmail, boolean goalMet) throws MessagingException {
        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setDestinatario(recipientEmail);
        if (goalMet) {
            emailDTO.setAsunto("Congratulations! You met your goal!");
            emailDTO.setMensaje("Well done! Keep up the great work.");
        } else {
            emailDTO.setAsunto("You didn't meet your goal this time");
            emailDTO.setMensaje("Don't worry, try again and you'll succeed!");
        }

        emailService.sendMail(emailDTO);
    }

    public void sendPurchaseNotification(String recipientEmail) throws MessagingException {
        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setDestinatario(recipientEmail);
        emailDTO.setAsunto("Your purchase has been confirmed");
        emailDTO.setMensaje("Thank you for your purchase! Your order is being processed.");

        emailService.sendMail(emailDTO);
    }

    @Scheduled(cron = "0 0 0 * * ?") // Ejecutar diariamente
    public void sendDailyNotifications() throws MessagingException {
        List<Usuario> users = userRepository.findByNotificationFrequency(NotificationFrequency.DAILY);
        for (Usuario user : users) {
            emailService.sendDailyReminder(user.getCorreo());
        }
    }

    @Scheduled(cron = "0 0 0 * * MON") // Ejecutar semanalmente
    public void sendWeeklyNotifications() throws MessagingException {
        List<Usuario> users = userRepository.findByNotificationFrequency(NotificationFrequency.WEEKLY);
        for (Usuario user : users) {
            emailService.sendWeeklyReminder(user.getCorreo());
        }
    }

    @Scheduled(cron = "0 0 0 1 * ?") // Ejecutar mensualmente
    public void sendMonthlyNotifications() throws MessagingException {
        List<Usuario> users = userRepository.findByNotificationFrequency(NotificationFrequency.MONTHLY);
        for (Usuario user : users) {
            emailService.sendMonthlyReminder(user.getCorreo());
        }
    }

    public void enviarCorreoConfirmacion(Suscripcion suscripcion) throws MessagingException {
        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setDestinatario(suscripcion.getUsuario().getCorreo());
        emailDTO.setAsunto("Confirmación de Suscripción");
        emailDTO.setMensaje("Te has suscrito exitosamente al contenido: " + suscripcion.getContenidoAdicional().getNombre());

        emailService.sendMail(emailDTO);
    }
}



