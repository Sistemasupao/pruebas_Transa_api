package upao.Transa.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upao.Transa.Repository.NotificationPreferenceRepository;
import upao.Transa.domain.Entity.NotificacionPreferencias;

@Service
public class NotificationPreferenceService {

    private final NotificationPreferenceRepository notificationPreferenceRepository;

    @Autowired
    public NotificationPreferenceService(NotificationPreferenceRepository notificationPreferenceRepository) {
        this.notificationPreferenceRepository = notificationPreferenceRepository;
    }

    public NotificacionPreferencias getUserPreferences(Long userId) {
        return notificationPreferenceRepository.findByUsuario_Id(userId);
    }
}
