package upao.Transa.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upao.Transa.Repository.ContenidoAdicionalRepository;
import upao.Transa.Repository.SuscripcionRepository;
import upao.Transa.Repository.UserRepository; // Importa el repositorio de usuarios
import upao.Transa.domain.Entity.ContenidoAdicional;
import upao.Transa.domain.Entity.Suscripcion;
import upao.Transa.domain.Entity.Usuario;
import upao.Transa.domain.Enum.TipoSuscripcion; // Asegúrate de importar el enum TipoSuscripcion

import java.time.LocalDateTime;

@Service
public class SuscripcionService {

    @Autowired
    private SuscripcionRepository suscripcionRepository;

    @Autowired
    private ContenidoAdicionalRepository contenidoAdicionalRepository;

    @Autowired
    private UserRepository userRepository;

    public Suscripcion suscribirUsuarioAContenido(Long usuarioId, Long contenidoId) {
        Usuario usuario = obtenerUsuarioPorId(usuarioId);
        ContenidoAdicional contenidoAdicional = contenidoAdicionalRepository.findById(contenidoId)
                .orElseThrow(() -> new RuntimeException("Contenido no encontrado"));

        Suscripcion suscripcion = new Suscripcion();
        suscripcion.setUsuario(usuario);
        suscripcion.setContenidoAdicional(contenidoAdicional);
        suscripcion.setFechainicio(LocalDateTime.now());
        suscripcion.setFechafin(calcularFechaFin(contenidoAdicional));
        suscripcion.setTipoSuscripcion(TipoSuscripcion.PREMIUM);

        return suscripcionRepository.save(suscripcion);
    }

    // Ejemplo de método para calcular la fecha fin (esto depende del contenido)
    private LocalDateTime calcularFechaFin(ContenidoAdicional contenido) {
        return LocalDateTime.now().plusMonths(1);
    }

    // Método para obtener el usuario por ID
    public Usuario obtenerUsuarioPorId(Long usuarioId) {
        return userRepository.findById(usuarioId)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }
}
