/**
package upao.Transa.Service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import upao.Transa.domain.Entity.Recurso;
import upao.Transa.dto.paypal.OrderCaptureResponse;
import upao.Transa.dto.paypal.OrderResponse;
import upao.Transa.dto.response.PaypalCaptureResponse;
import upao.Transa.dto.response.PaypalOrderResponse;

@AllArgsConstructor
@Service
public class CheckoutService {
    private PaypalService paypalService;
    private RecursoService recursoService;

    public PaypalOrderResponse createPaypalPaymentUrl(Long recursoid, String returnUrl, String cancelUrl) {
        OrderResponse orderResponse = paypalService.createOrder(recursoid, returnUrl, cancelUrl);

        String paypalUrl = orderResponse
                .getLinks()
                .stream()
                .filter(link -> link.getRel().equals("approve"))
                .findFirst()
                .orElseThrow(RuntimeException::new)
                .getHref();

        return new PaypalOrderResponse(paypalUrl);
    }

    public PaypalCaptureResponse capturePaypalPayment(String orderId) {
        OrderCaptureResponse orderCaptureResponse = paypalService.captureOrder(orderId);
        boolean completed = orderCaptureResponse.getStatus().equals("COMPLETED");

        PaypalCaptureResponse paypalCaptureResponse = new PaypalCaptureResponse();
        paypalCaptureResponse.setCompleted(completed);

        if (completed) {
            String purchaseIdStr = orderCaptureResponse.getPurchaseUnits().getFirst().getReferenceId();
            Recurso recurso = recursoService.confirmReservationPayment(Long.parseLong(purchaseIdStr));
            paypalCaptureResponse.setReservationId(recurso.getRecursoid());
        }
        return paypalCaptureResponse;
    }

}
}
 **/
