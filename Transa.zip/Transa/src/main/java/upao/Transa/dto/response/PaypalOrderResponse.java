package upao.Transa.dto.response;

import lombok.Data;

@Data
public class PaypalOrderResponse {
    private String paypalUrl;
}
