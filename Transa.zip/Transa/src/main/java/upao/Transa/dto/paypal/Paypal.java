package upao.Transa.dto.paypal;

import lombok.Data;

@Data
public class Paypal {
    private ExperienceContext experienceContext;
}
