package upao.Transa.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import upao.Transa.domain.Enum.TipoRecurso;

import java.math.BigDecimal;

@Data
public class RecursoRequestDTO {
    private String nombreRecurso;
    private String descripcionRecurso;
    private BigDecimal precioRecurso;
    private TipoRecurso tipoRecurso;
    private String autorNombre;
}
