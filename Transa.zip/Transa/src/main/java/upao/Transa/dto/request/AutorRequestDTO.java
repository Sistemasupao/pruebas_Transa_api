package upao.Transa.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class AutorRequestDTO {
        @NotEmpty(message = "La contraseña no puede estar vacía")
        private String contrasena;
        @Email(message = "Email no válido")
        @NotEmpty(message = "El correo no puede estar vacío")
        private String correo;
        @NotEmpty(message = "La especialidad no puede estar vacía")
        private String especialidad;
        @NotEmpty(message = "El nombre no puede estar vacío")
        private String nombre;
        @NotEmpty(message = "El rol no puede estar vacío")
        private String role;
        @NotEmpty(message = "El teléfono no puede estar vacío")
        private String telefono;
}
