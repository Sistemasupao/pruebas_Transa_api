package upao.Transa.dto.response;

import lombok.Data;

@Data
public class AutorProfileResponseDTO {
    private Long id;
    private String nombre;
    private String correo;
    private String especialidad;
    private String telefono;
    private String role;
}
