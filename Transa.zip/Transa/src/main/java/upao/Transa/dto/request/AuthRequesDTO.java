package upao.Transa.dto.request;

import lombok.Data;

@Data
public class AuthRequesDTO {
    private String correo;
    private String contrasena;
}
