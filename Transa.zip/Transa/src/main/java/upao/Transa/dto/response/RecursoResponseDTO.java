package upao.Transa.dto.response;

import lombok.Data;
import upao.Transa.domain.Entity.Recurso;

import java.math.BigDecimal;
@Data
public class RecursoResponseDTO {

    private String nombreRecurso;
    private String descripcionRecurso;
    private BigDecimal precioRecurso;

    public RecursoResponseDTO(Recurso recurso) {
        this.nombreRecurso = recurso.getNombreRecurso();
        this.descripcionRecurso = recurso.getDescripcionRecurso();
        this.precioRecurso = recurso.getPrecioRecurso();
    }
}