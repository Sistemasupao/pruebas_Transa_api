package upao.Transa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransaApplicationTests {

	@Test
	void contextLoads() {
	}

}
